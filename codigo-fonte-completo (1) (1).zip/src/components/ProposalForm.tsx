import { useState, useEffect } from 'react';
import { Send, CheckCircle2, Zap, MessageSquare, Clock, ArrowRight, ShieldCheck } from 'lucide-react';
import { BRAND_INFO, SERVICES_LIST } from '../data/portfolioData';

interface ProposalFormProps {
  initialServiceId?: string;
  initialProjectNote?: string;
}

export default function ProposalForm({ initialServiceId, initialProjectNote }: ProposalFormProps) {
  const [fullName, setFullName] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [segment, setSegment] = useState('petshop');
  const [serviceId, setServiceId] = useState(initialServiceId || 'sites-petshop-empresas');
  const [urgency, setUrgency] = useState<'same-day' | 'standard' | 'planning'>('same-day');
  const [goal, setGoal] = useState('Aumentar agendamentos e faturamento mensal');
  const [notes, setNotes] = useState(initialProjectNote || '');

  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedData, setSubmittedData] = useState<any>(null);

  useEffect(() => {
    if (initialServiceId) {
      setServiceId(initialServiceId);
    }
  }, [initialServiceId]);

  useEffect(() => {
    if (initialProjectNote) {
      setNotes((prev) => prev ? `${prev} · Referência: ${initialProjectNote}` : `Referência de projeto de interesse: ${initialProjectNote}`);
    }
  }, [initialProjectNote]);

  const formatWhatsAppText = () => {
    const serviceName = SERVICES_LIST.find(s => s.id === serviceId)?.title || 'Criação de Site';
    const urgencyLabel = urgency === 'same-day' ? '⚡ Entrega no mesmo dia' : urgency === 'standard' ? '📅 Padrão (2 a 4 dias)' : '🎯 Planejamento';
    
    const text = `Olá Marcelo Farias! Gostaria de solicitar uma proposta de site para minha empresa:

• Nome: ${fullName}
• Empresa: ${companyName}
• Nicho: ${segment === 'petshop' ? 'Pet Shop / Banho & Tosa / Veterinária' : segment === 'servicos' ? 'Prestador de Serviços' : segment === 'autonomo' ? 'Profissional Autônomo' : 'Empresa / Comércio'}
• Serviço: ${serviceName}
• Prazo Desejado: ${urgencyLabel}
• Objetivo: ${goal}
${notes ? `• Detalhes adicionais: ${notes}` : ''}

Vi pelo seu portfólio na Webnex Studio. Podemos alinhar os próximos passos?`;

    return encodeURIComponent(text);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!fullName.trim() || !whatsapp.trim() || !companyName.trim()) {
      alert('Por favor, preencha os campos obrigatórios (Nome, WhatsApp e Nome da Empresa).');
      return;
    }

    const payload = {
      fullName,
      whatsapp,
      companyName,
      segment,
      serviceName: SERVICES_LIST.find(s => s.id === serviceId)?.title,
      urgency,
      goal,
      notes,
      timestamp: new Date().toLocaleTimeString('pt-BR')
    };

    setSubmittedData(payload);
    setIsSubmitted(true);

    // Open WhatsApp directly with formatted message to Marcelo Farias
    const encoded = formatWhatsAppText();
    const waUrl = `https://wa.me/55${BRAND_INFO.whatsappNumber}?text=${encoded}`;
    window.open(waUrl, '_blank');
  };

  const handleResetForm = () => {
    setIsSubmitted(false);
    setFullName('');
    setWhatsapp('');
    setCompanyName('');
    setNotes('');
  };

  return (
    <section id="proposta" className="py-20 md:py-28 relative bg-[#0b1329] border-t border-slate-800">
      
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-[140px] pointer-events-none -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <p className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-2">
            Ação Principal
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-4 text-balance">
            {BRAND_INFO.primaryCtaText}
          </h2>
          <p className="text-sm sm:text-base text-slate-300">
            Preencha as informações do seu negócio abaixo. Você receberá um diagnóstico direto com Marcelo Farias com foco em acelerar seu faturamento.
          </p>
        </div>

        {/* Confirmation Card if submitted */}
        {isSubmitted && submittedData ? (
          <div className="p-8 sm:p-10 rounded-2xl bg-slate-900 border border-emerald-500/50 shadow-2xl animate-in fade-in zoom-in-95 duration-300 text-center">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 mx-auto flex items-center justify-center mb-5">
              <CheckCircle2 className="w-9 h-9" />
            </div>

            <h3 className="text-2xl font-bold text-white mb-2">
              Solicitação Gerada com Sucesso!
            </h3>
            <p className="text-sm text-slate-300 max-w-md mx-auto mb-6">
              Obrigado, <strong className="text-white">{submittedData.fullName}</strong>. Sua solicitação para a empresa <strong className="text-white">{submittedData.companyName}</strong> foi estruturada para atendimento imediato.
            </p>

            <div className="max-w-md mx-auto text-left p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-300 space-y-2 mb-6">
              <div className="flex justify-between">
                <span className="text-slate-400">Serviço:</span>
                <span className="text-white font-medium">{submittedData.serviceName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Prazo:</span>
                <span className="text-blue-400 font-semibold">
                  {submittedData.urgency === 'same-day' ? '⚡ Entrega no mesmo dia' : 'Padrão'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Canal direto:</span>
                <span className="text-emerald-400 font-mono">WhatsApp (91) 98235-8580</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <a
                href={`https://wa.me/55${BRAND_INFO.whatsappNumber}?text=${formatWhatsAppText()}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-lg"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Reabrir Conversa no WhatsApp</span>
              </a>

              <button
                onClick={handleResetForm}
                className="w-full sm:w-auto px-5 py-3.5 text-sm font-medium text-slate-300 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
              >
                Solicitar Outro Projeto
              </button>
            </div>
          </div>
        ) : (
          /* The Proposal Request Form */
          <form
            onSubmit={handleSubmit}
            className="p-6 sm:p-10 rounded-2xl bg-slate-900/90 border border-slate-800 shadow-2xl backdrop-blur-md"
          >
            {/* Top Guarantees Pill Strip */}
            <div className="flex flex-wrap items-center justify-between gap-3 pb-6 mb-8 border-b border-slate-800 text-xs text-slate-300">
              <span className="flex items-center gap-1.5 text-blue-400 font-medium">
                <Zap className="w-3.5 h-3.5" /> Opção de entrega no mesmo dia
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400 font-medium">
                <ShieldCheck className="w-3.5 h-3.5" /> Atendimento direto com Marcelo Farias
              </span>
              <span className="flex items-center gap-1.5 text-slate-400">
                <Clock className="w-3.5 h-3.5" /> Retorno médio &lt; 15 min
              </span>
            </div>

            <div className="space-y-6">
              
              {/* Row 1: Personal and Contact */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                    Seu Nome Completo *
                  </label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ex: Carlos Mendes"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                    Seu WhatsApp com DDD *
                  </label>
                  <input
                    type="tel"
                    required
                    value={whatsapp}
                    onChange={(e) => setWhatsapp(e.target.value)}
                    placeholder="Ex: (91) 98888-7777"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  />
                </div>
              </div>

              {/* Row 2: Company and Business Nicho */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                    Nome da Sua Empresa / Negócio *
                  </label>
                  <input
                    type="text"
                    required
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    placeholder="Ex: Pet Shop AuAu Feliz"
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                    Segmento de Atuação
                  </label>
                  <select
                    value={segment}
                    onChange={(e) => setSegment(e.target.value)}
                    className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  >
                    <option value="petshop">Pet Shop / Banho & Tosa / Clínica Veterinária</option>
                    <option value="servicos">Empresa de Prestação de Serviços</option>
                    <option value="autonomo">Profissional Autônomo / Especialista</option>
                    <option value="comercio">Comércio / Venda de Produtos</option>
                    <option value="outro">Outro segmento</option>
                  </select>
                </div>
              </div>

              {/* Row 3: Service Selection */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                  Serviço Principal de Interesse
                </label>
                <select
                  value={serviceId}
                  onChange={(e) => setServiceId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                >
                  {SERVICES_LIST.map((srv) => (
                    <option key={srv.id} value={srv.id}>
                      {srv.title} — {srv.shortDesc}
                    </option>
                  ))}
                </select>
              </div>

              {/* Row 4: Urgency / Prazo */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                  Qual é o prazo ideal para seu projeto?
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setUrgency('same-day')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      urgency === 'same-day'
                        ? 'bg-blue-950/80 border-blue-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="flex items-center gap-1.5 text-xs font-bold text-amber-400 mb-1">
                      <Zap className="w-3.5 h-3.5" /> Entrega no mesmo dia
                    </span>
                    <p className="text-[11px] text-slate-400">Para lançamentos rápidos e páginas essenciais</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUrgency('standard')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      urgency === 'standard'
                        ? 'bg-blue-950/80 border-blue-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="block text-xs font-bold text-blue-300 mb-1">
                      Padrão (2 a 4 dias)
                    </span>
                    <p className="text-[11px] text-slate-400">Desenvolvimento com revisão e refinamento</p>
                  </button>

                  <button
                    type="button"
                    onClick={() => setUrgency('planning')}
                    className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                      urgency === 'planning'
                        ? 'bg-blue-950/80 border-blue-500 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="block text-xs font-bold text-slate-200 mb-1">
                      Planejando próximas semanas
                    </span>
                    <p className="text-[11px] text-slate-400">Quero alinhar orçamento com antecedência</p>
                  </button>
                </div>
              </div>

              {/* Row 5: Notes & Additional details */}
              <div>
                <label className="block text-xs font-semibold text-slate-200 uppercase tracking-wider mb-2">
                  Conte um pouco sobre o que precisa ou link do seu Instagram
                </label>
                <textarea
                  rows={3}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ex: Quero um site para meu pet shop com tabela de banho e tosa e botão para agendar pelo WhatsApp..."
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-slate-800 text-white placeholder-slate-500 text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                />
              </div>

              {/* Main Submit Action */}
              <div className="pt-4">
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-3 px-8 py-4 text-base font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-xl shadow-blue-600/30 active:scale-[0.99] transition-all cursor-pointer group"
                >
                  <Send className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                  <span>{BRAND_INFO.primaryCtaText}</span>
                </button>
                <p className="text-center text-xs text-slate-400 mt-3">
                  Ao enviar, sua proposta é formatada e enviada diretamente para o WhatsApp de Marcelo Farias. Sem espera.
                </p>
              </div>

            </div>
          </form>
        )}

      </div>
    </section>
  );
}
