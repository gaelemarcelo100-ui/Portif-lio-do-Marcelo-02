import { useState } from 'react';
import { X, Download, CheckCircle2, FileArchive, ArrowRight, Loader2, AlertCircle } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function DownloadModal({ isOpen, onClose }: DownloadModalProps) {
  const [downloadingFile, setDownloadingFile] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleDownload = async (url: string, fileName: string, expectedSizeMB: string) => {
    setDownloadingFile(fileName);
    setStatusMessage(`Baixando pacote (${expectedSizeMB})... Aguarde alguns segundos.`);
    setErrorMessage(null);

    try {
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Servidor retornou erro ${response.status}`);
      }

      const blob = await response.blob();
      const actualSize = blob.size;

      if (actualSize === 0) {
        throw new Error('O arquivo retornou vazio pelo navegador.');
      }

      const sizeMB = (actualSize / (1024 * 1024)).toFixed(2);
      
      // Create local Blob URL to ensure file is saved from memory with full content
      const blobUrl = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = blobUrl;
      link.download = fileName;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setTimeout(() => window.URL.revokeObjectURL(blobUrl), 2000);
      setStatusMessage(`✅ Sucesso! Arquivo '${fileName}' salvo no seu computador com ${sizeMB} MB!`);
    } catch (err: any) {
      console.error('Erro no download:', err);
      setErrorMessage(`Erro ao processar download direto: ${err?.message || 'Tente novamente'}`);
      // Fallback: try opening url in new tab
      window.open(url, '_blank');
    } finally {
      setDownloadingFile(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[92vh] overflow-y-auto">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg bg-slate-800/60 hover:bg-slate-800 transition-colors cursor-pointer"
          aria-label="Fechar janela de download"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 text-xs font-semibold text-blue-400 uppercase tracking-wider mb-1">
            <FileArchive className="w-4 h-4" />
            <span>Download Oficial dos Arquivos do Site</span>
          </div>
          <h3 className="text-2xl font-bold text-white">
            Baixar Arquivo ZIP do Projeto
          </h3>
          <p className="text-xs sm:text-sm text-slate-300 mt-1">
            Os arquivos são baixados diretamente da memória do navegador para garantir que o ZIP chegue com o tamanho completo (sem arquivo vazio).
          </p>
        </div>

        {/* Status or Error Notifications */}
        {statusMessage && (
          <div className="mb-6 p-4 rounded-xl bg-emerald-950/80 border border-emerald-600/70 text-emerald-200 text-xs sm:text-sm flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{statusMessage}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mb-6 p-4 rounded-xl bg-red-950/80 border border-red-600/70 text-red-200 text-xs sm:text-sm flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* The 3 Download Options */}
        <div className="space-y-4 mb-6">
          
          {/* Option 1: The 5.6 MB Source Code ZIP (The exact one requested!) */}
          <div className="p-5 rounded-xl bg-slate-900 border-2 border-blue-500/80 hover:border-blue-400 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-white bg-blue-600 px-2 py-0.5 rounded">
                  Recomendado para GitHub & Lovable
                </span>
                <span className="text-xs font-mono font-bold text-blue-300">
                  5.6 MB
                </span>
              </div>
              <h4 className="text-base font-bold text-white mt-1.5">
                Código-Fonte Completo (React + Vite + Fotos)
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                Contém todos os arquivos brutos (`package.json`, `src/`, `public/images/`, `netlify.toml`, fotos em alta resolução). Perfeito para subir no GitHub e puxar na Lovable!
              </p>
            </div>

            <button
              onClick={() => handleDownload('/codigo-fonte-completo.zip', 'codigo-fonte-completo.zip', '5.6 MB')}
              disabled={downloadingFile !== null}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-bold text-white bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 rounded-xl transition-all shadow-md shrink-0 cursor-pointer"
            >
              {downloadingFile === 'codigo-fonte-completo.zip' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Baixando 5.6 MB...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Baixar 5.6 MB</span>
                </>
              )}
            </button>
          </div>

          {/* Option 2: The Master Bundle (8.4 MB) */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300 bg-slate-800 px-2 py-0.5 rounded">
                  Pacote Master Unificado
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  8.4 MB
                </span>
              </div>
              <h4 className="text-base font-bold text-white mt-1.5">
                Tudo em Um Só Arquivo (Código + Site Compilado)
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                Contém tanto o código-fonte quanto a pasta `dist` já gerada para quem quer ter tudo em um único download.
              </p>
            </div>

            <button
              onClick={() => handleDownload('/webnex-studio-completo-master.zip', 'webnex-studio-completo-master.zip', '8.4 MB')}
              disabled={downloadingFile !== null}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-slate-100 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-800 border border-slate-600 rounded-xl transition-all shrink-0 cursor-pointer"
            >
              {downloadingFile === 'webnex-studio-completo-master.zip' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Baixando 8.4 MB...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Baixar 8.4 MB</span>
                </>
              )}
            </button>
          </div>

          {/* Option 3: Ready compiled static site for Netlify Drop (2.9 MB) */}
          <div className="p-5 rounded-xl bg-slate-900 border border-slate-700 hover:border-slate-600 transition-colors flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-800">
                  Para Netlify Drop Direto
                </span>
                <span className="text-xs font-mono font-bold text-slate-300">
                  2.9 MB
                </span>
              </div>
              <h4 className="text-base font-bold text-white mt-1.5">
                Site Compilado Pronto (HTML + CSS + Imagens)
              </h4>
              <p className="text-xs text-slate-300 mt-1">
                Para arrastar direto no app.netlify.com/drop sem precisar compilar.
              </p>
            </div>

            <button
              onClick={() => handleDownload('/site-completo-pronto-para-usar.zip', 'site-completo-pronto-para-usar.zip', '2.9 MB')}
              disabled={downloadingFile !== null}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-3 text-xs sm:text-sm font-semibold text-slate-100 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-800 border border-slate-600 rounded-xl transition-all shrink-0 cursor-pointer"
            >
              {downloadingFile === 'site-completo-pronto-para-usar.zip' ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Baixando 2.9 MB...</span>
                </>
              ) : (
                <>
                  <Download className="w-4 h-4" />
                  <span>Baixar 2.9 MB</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Bottom Help Instructions */}
        <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-400 space-y-1.5">
          <p className="font-semibold text-slate-200">
            Dica para garantir que seu download não fique vazio:
          </p>
          <p>
            • Ao clicar no botão acima, aguarde a barra de progresso verde confirmar que os 5.6 MB foram transferidos para a memória do seu navegador.
          </p>
          <p>
            • O arquivo é salvo automaticamente na sua pasta de <strong>Downloads</strong> do Windows/Mac.
          </p>
        </div>

      </div>
    </div>
  );
}
