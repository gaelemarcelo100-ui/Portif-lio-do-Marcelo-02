import { Zap, UserCheck, Sparkles, ShieldCheck, MessageCircle, Clock, CheckCircle } from 'lucide-react';
import { DIFFERENTIATORS_LIST, BRAND_INFO } from '../data/portfolioData';

interface DifferentiatorsProps {
  onOpenProposal: () => void;
}

export default function Differentiators({ onOpenProposal }: DifferentiatorsProps) {
  const getIcon = (name: string) => {
    switch (name) {
      case 'Zap':
        return <Zap className="w-6 h-6 text-amber-400" />;
      case 'UserCheck':
        return <UserCheck className="w-6 h-6 text-blue-400" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-indigo-400" />;
      case 'ShieldCheck':
        return <ShieldCheck className="w-6 h-6 text-emerald-400" />;
      case 'MessageCircle':
        return <MessageCircle className="w-6 h-6 text-sky-400" />;
      case 'Clock':
        return <Clock className="w-6 h-6 text-purple-400" />;
      default:
        return <CheckCircle className="w-6 h-6 text-blue-400" />;
    }
  };

  return (
    <section id="diferenciais" className="py-20 md:py-28 relative bg-[#070d1e] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-3">
            Por que escolher a Webnex Studio
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-4 text-balance">
            Diferenciais competitivos que aceleram o retorno do seu investimento
          </h2>
          <p className="text-base text-slate-300">
            Trabalhar com a Webnex Studio é ter a certeza de prazos respeitados, comunicação transparente e um parceiro comprometido com o seu faturamento.
          </p>
        </div>

        {/* 6 Differentiators in 2-column or 3-column structured grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {DIFFERENTIATORS_LIST.map((diff, index) => {
            const isHighlight = diff.id === 'entrega-mesmo-dia' || diff.id === 'atendimento-direto';
            return (
              <div
                key={diff.id}
                className={`p-6 sm:p-7 rounded-2xl transition-all duration-300 flex flex-col justify-between ${
                  isHighlight
                    ? 'bg-slate-900/90 border border-blue-500/50 shadow-lg shadow-blue-950/30'
                    : 'bg-slate-900/50 border border-slate-800/80 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div className="p-3 rounded-xl bg-slate-800/80 border border-slate-700/60 inline-flex">
                      {getIcon(diff.iconName)}
                    </div>
                    <span className="font-mono text-xs text-slate-400">
                      0{index + 1}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-white mb-2.5">
                    {diff.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {diff.description}
                  </p>
                </div>

                <div className="pt-3 border-t border-slate-800 text-xs text-blue-300 font-medium flex items-start gap-1.5">
                  <span className="text-slate-400">Garantia:</span>
                  <span>{diff.proof}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mid-page Action Callout */}
        <div className="mt-14 text-center">
          <button
            onClick={onOpenProposal}
            className="inline-flex items-center justify-center gap-2 px-8 py-4 text-sm sm:text-base font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-lg shadow-blue-600/20 active:scale-[0.98] transition-all cursor-pointer"
          >
            <span>{BRAND_INFO.primaryCtaText}</span>
          </button>
        </div>

      </div>
    </section>
  );
}
