import { ArrowRight, CheckCircle2, Award, HeartHandshake, Sparkles, Instagram, MessageCircle } from 'lucide-react';
import { BRAND_INFO } from '../data/portfolioData';

interface AboutProps {
  onOpenProposal: () => void;
}

export default function About({ onOpenProposal }: AboutProps) {
  return (
    <section id="sobre" className="py-20 md:py-28 relative border-t border-slate-800/80 bg-[#080e22]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Left Column: Portrait & Studio Card */}
          <div className="lg:col-span-5">
            <div className="relative">
              {/* Decorative subtle border frame */}
              <div className="relative rounded-2xl overflow-hidden bg-slate-800/50 p-2 border border-slate-700/60 shadow-2xl">
                <div className="relative aspect-square rounded-xl overflow-hidden bg-slate-900">
                  <img
                    src="./images/marcelo_farias_portrait_1794252805449.jpg"
                    alt="Marcelo Farias — Fundador da Webnex Studio"
                    className="w-full h-full object-cover object-top hover:scale-[1.03] transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#060a17]/90 via-[#060a17]/20 to-transparent pointer-events-none" />

                  {/* Overlay text on portrait */}
                  <div className="absolute bottom-4 left-4 right-4">
                    <p className="text-lg font-bold text-white">Marcelo Farias</p>
                    <p className="text-xs text-blue-300">Fundador da Webnex Studio · Estrategista Digital</p>
                  </div>
                </div>

                {/* Social Quick Links */}
                <div className="flex items-center justify-between px-3 py-3 border-t border-slate-800 text-xs">
                  <a
                    href={BRAND_INFO.instagramUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
                  >
                    <Instagram className="w-4 h-4 text-pink-400" />
                    <span>@{BRAND_INFO.instagramHandle}</span>
                  </a>
                  <a
                    href={BRAND_INFO.whatsappLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 text-slate-300 hover:text-emerald-400 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4 text-emerald-400" />
                    <span>{BRAND_INFO.whatsappFormatted}</span>
                  </a>
                </div>
              </div>

              {/* Floating Credibility Pill */}
              <div className="hidden sm:flex absolute -bottom-6 -right-6 p-4 rounded-xl bg-slate-900/95 border border-slate-700/80 shadow-xl max-w-xs items-center gap-3 backdrop-blur-md">
                <div className="w-10 h-10 rounded-lg bg-blue-600/20 text-blue-400 flex items-center justify-center shrink-0">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-xs font-semibold text-white">Foco Total em Faturamento</p>
                  <p className="text-[11px] text-slate-400">Design planejado para gerar pedidos e agendamentos</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Narrative, Mission, Principles */}
          <div className="lg:col-span-7 flex flex-col items-start">
            
            {/* Section Tag */}
            <div className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-3 flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Sobre Marcelo Farias & Webnex Studio</span>
            </div>

            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-6 text-balance">
              Criamos presença real para seu negócio deixar de ser apenas uma opção e virar referência.
            </h2>

            {/* Official Brief Quote & Core Mission */}
            <div className="p-5 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-200 text-sm sm:text-base leading-relaxed mb-6">
              <p className="mb-3 font-medium text-white">
                "A Webnex Studio nasceu com um propósito: dar vida e presença real ao seu negócio no mundo digital!"
              </p>
              <p className="text-slate-300">
                Sou Marcelo Farias, criador da Webnex Studio, e meu objetivo é transformar negócios em marcas que se destacam, conquistam credibilidade e deixam de ser apenas mais uma opção para se tornarem uma referência no mercado.
              </p>
            </div>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed mb-6">
              Muitas empresas perdem clientes todos os dias não pela qualidade do seu trabalho, mas porque possuem uma presença online antiquada, lenta ou inexistente. Na Webnex Studio, unimos design minimalista de padrão internacional, copywriting persuasivo e integrações inteligentes (como agendamentos instantâneos no WhatsApp e agentes de IA) para transformar acessos em receita palpável.
            </p>

            {/* 3 Core pillars */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 w-full mb-8">
              <div className="p-3.5 rounded-lg bg-slate-900/50 border border-slate-800/80">
                <div className="flex items-center gap-2 text-white font-semibold text-sm mb-1">
                  <HeartHandshake className="w-4 h-4 text-blue-400" />
                  <span>Atendimento Humanizado</span>
                </div>
                <p className="text-xs text-slate-400">
                  Conversa direta comigo, alinhando suas metas de faturamento sem enrolação corporativa.
                </p>
              </div>

              <div className="p-3.5 rounded-lg bg-slate-900/50 border border-slate-800/80">
                <div className="flex items-center gap-2 text-white font-semibold text-sm mb-1">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Entrega com Rapidez Recorde</span>
                </div>
                <p className="text-xs text-slate-400">
                  Possibilidade de colocar sua landing page no ar no mesmo dia com máxima qualidade.
                </p>
              </div>
            </div>

            {/* Action button */}
            <button
              onClick={onOpenProposal}
              className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md shadow-blue-600/20 active:scale-[0.98] transition-all cursor-pointer group"
            >
              <span>{BRAND_INFO.primaryCtaText}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

          </div>

        </div>

      </div>
    </section>
  );
}
