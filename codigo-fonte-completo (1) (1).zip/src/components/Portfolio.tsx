import { useState } from 'react';
import { ArrowUpRight, Check, Sparkles, X, Heart } from 'lucide-react';
import { PROJECTS_LIST, BRAND_INFO } from '../data/portfolioData';
import { ProjectItem } from '../types';

interface PortfolioProps {
  onRequestSimilarProject: (projectTitle: string) => void;
}

export default function Portfolio({ onRequestSimilarProject }: PortfolioProps) {
  const [activeFilter, setActiveFilter] = useState<'all' | 'petshop' | 'landing' | 'ia'>('all');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);

  const filteredProjects = activeFilter === 'all'
    ? PROJECTS_LIST
    : PROJECTS_LIST.filter(p => p.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 md:py-28 relative bg-[#0b1329] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header and Interactive Category Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-3">
              Portfólio & Casos de Sucesso
            </p>
            <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-3 text-balance">
              Projetos reais com foco em resultado e faturamento
            </h2>
            <p className="text-base text-slate-300">
              Veja como desenhamos estruturas limpas que valorizam a marca do cliente e transformam visitantes em clientes diários.
            </p>
          </div>

          {/* Interactive filter tabs (Buttons with functional click handlers as per constitution §1.A) */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-900/90 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeFilter === 'all'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              Todos os Projetos
            </button>
            <button
              onClick={() => setActiveFilter('petshop')}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                activeFilter === 'petshop'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Heart className="w-3 h-3 text-pink-400" />
              <span>Nicho Pet Shop</span>
            </button>
            <button
              onClick={() => setActiveFilter('landing')}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeFilter === 'landing'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              Landing Pages
            </button>
            <button
              onClick={() => setActiveFilter('ia')}
              className={`px-3.5 py-2 text-xs font-medium rounded-lg transition-colors cursor-pointer whitespace-nowrap ${
                activeFilter === 'ia'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              Integração IA
            </button>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className="rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 overflow-hidden flex flex-col justify-between group transition-all duration-300 hover:shadow-2xl hover:shadow-blue-950/20"
            >
              {/* Media Preview Box */}
              <div className="relative aspect-[16/10] overflow-hidden bg-slate-950">
                <img
                  src={project.imageUrl}
                  alt={`Screenshot do projeto ${project.title}`}
                  className="w-full h-full object-cover object-top group-hover:scale-[1.03] transition-transform duration-500"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0b1329] via-transparent to-transparent opacity-90 pointer-events-none" />

                {/* Top Corner Badge for Pet Shop or IA */}
                <div className="absolute top-4 left-4">
                  <span className="text-xs font-medium text-slate-200 bg-[#060a17]/90 backdrop-blur-md px-3 py-1 rounded-md border border-slate-700/80">
                    {project.categoryLabel}
                  </span>
                </div>

                {/* Primary Metric Floating Badge */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-xl bg-[#060a17]/95 backdrop-blur-md border border-slate-700/80 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-slate-400 block">Resultado Conquistado:</span>
                    <span className="text-xs font-medium text-slate-200 line-clamp-1">{project.metricLabel}</span>
                  </div>
                  <span className="text-xl font-bold font-mono text-emerald-400 shrink-0 tabular-nums ml-2">
                    {project.resultMetric}
                  </span>
                </div>
              </div>

              {/* Project Details */}
              <div className="p-6 sm:p-7 flex flex-col flex-1 justify-between">
                <div>
                  {/* Clean unboxed metadata separator */}
                  <div className="flex items-center gap-2 text-xs text-slate-400 mb-2">
                    <span>Cliente: {project.client}</span>
                    <span aria-hidden="true">·</span>
                    <span>Brasil</span>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-3 group-hover:text-blue-300 transition-colors">
                    {project.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-6">
                    {project.description}
                  </p>

                  {/* Highlights list */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-6">
                    {project.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-center gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                        <span className="truncate">{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Action buttons */}
                <div className="pt-4 border-t border-slate-800 flex items-center justify-between gap-4">
                  <button
                    onClick={() => setSelectedProject(project)}
                    className="text-xs sm:text-sm font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer py-1"
                  >
                    Ver detalhes do projeto
                  </button>

                  <button
                    onClick={() => onRequestSimilarProject(project.title)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors cursor-pointer"
                  >
                    <span>Quero um assim</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Project Details Modal */}
      {selectedProject && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#0b1329] border border-slate-700 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            
            <button
              onClick={() => setSelectedProject(null)}
              className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-lg bg-slate-800/60 hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Fechar detalhes do projeto"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-4">
              <span className="text-xs font-medium text-blue-400 uppercase tracking-wider">
                {selectedProject.categoryLabel}
              </span>
              <h3 className="text-2xl font-bold text-white mt-1">
                {selectedProject.title}
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                Cliente atendido: {selectedProject.client} · Solução Webnex Studio
              </p>
            </div>

            <div className="rounded-xl overflow-hidden mb-6 aspect-video bg-slate-900 border border-slate-800">
              <img
                src={selectedProject.imageUrl}
                alt={selectedProject.title}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>

            {/* Impact metric highlight */}
            <div className="p-4 rounded-xl bg-slate-900 border border-blue-900/40 mb-6 flex items-center justify-between">
              <div>
                <p className="text-xs text-slate-400">Impacto Direto:</p>
                <p className="text-sm font-medium text-white">{selectedProject.metricLabel}</p>
              </div>
              <span className="text-2xl font-bold text-emerald-400 font-mono">
                {selectedProject.resultMetric}
              </span>
            </div>

            <div className="space-y-4 mb-8 text-sm text-slate-300">
              <p>{selectedProject.description}</p>
              
              <div>
                <h4 className="font-semibold text-white mb-2 text-xs uppercase tracking-wider">
                  Destaques da implementação:
                </h4>
                <ul className="space-y-2">
                  {selectedProject.features.map((feat, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-xs sm:text-sm text-slate-300">
                      <Sparkles className="w-4 h-4 text-blue-400 shrink-0" />
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-4 border-t border-slate-800">
              <button
                onClick={() => setSelectedProject(null)}
                className="w-full sm:w-auto px-5 py-2.5 text-xs sm:text-sm font-medium text-slate-300 hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                Voltar
              </button>
              <button
                onClick={() => {
                  const title = selectedProject.title;
                  setSelectedProject(null);
                  onRequestSimilarProject(title);
                }}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-md transition-all cursor-pointer"
              >
                <span>{BRAND_INFO.primaryCtaText}</span>
              </button>
            </div>

          </div>
        </div>
      )}

    </section>
  );
}
