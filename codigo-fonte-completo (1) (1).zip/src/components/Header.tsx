import { useState, useEffect } from 'react';
import { Menu, X, ArrowRight, ShieldCheck } from 'lucide-react';
import { BRAND_INFO } from '../data/portfolioData';

interface HeaderProps {
  onOpenProposalModal?: () => void;
  onOpenDownloadModal?: () => void;
}

export default function Header({ onOpenProposalModal, onOpenDownloadModal }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollTo = (id: string) => {
    setIsMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCtaClick = () => {
    setIsMobileMenuOpen(false);
    if (onOpenProposalModal) {
      onOpenProposalModal();
    } else {
      handleScrollTo('proposta');
    }
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#060a17]/95 backdrop-blur-md border-b border-slate-800/80 py-3 shadow-lg shadow-black/20'
          : 'bg-[#0b1329]/80 backdrop-blur-sm border-b border-slate-800/40 py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element) */}
        <a
          href="#inicio"
          onClick={(e) => {
            e.preventDefault();
            handleScrollTo('inicio');
          }}
          className="text-lg sm:text-xl font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2 group"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500 group-hover:scale-125 transition-transform"></span>
          <span>Marcelo Farias</span>
          <span className="text-slate-400 font-normal text-sm sm:text-base hidden sm:inline">· Webnex Studio</span>
        </a>

        {/* Zone 2: 4-5 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-slate-300">
          <button
            onClick={() => handleScrollTo('sobre')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Sobre
          </button>
          <button
            onClick={() => handleScrollTo('servicos')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Serviços
          </button>
          <button
            onClick={() => handleScrollTo('diferenciais')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Diferenciais
          </button>
          <button
            onClick={() => handleScrollTo('portfolio')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Projetos
          </button>
          <button
            onClick={() => handleScrollTo('depoimentos')}
            className="hover:text-white transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            Depoimentos
          </button>
        </nav>

        {/* Zone 3: 1 Primary Action + Quick Download Button */}
        <div className="flex items-center gap-2.5 shrink-0">
          {onOpenDownloadModal && (
            <button
              onClick={onOpenDownloadModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-300 bg-emerald-950/70 hover:bg-emerald-900/90 border border-emerald-600/50 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              title="Baixar arquivo ZIP completo do projeto (5.6 MB)"
            >
              <span>Baixar ZIP (5.6 MB)</span>
            </button>
          )}

          <button
            onClick={handleCtaClick}
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm hover:shadow-blue-500/20 active:scale-[0.98] transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>Solicitar Proposta</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          {/* Mobile hamburger button */}
          <button
            type="button"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 text-slate-300 hover:text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            aria-label="Abrir menu de navegação"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-[#070c1e] border-b border-slate-800 px-5 pt-3 pb-6 animate-in fade-in slide-in-from-top duration-200">
          <nav className="flex flex-col gap-3 text-base font-medium text-slate-300 mb-5">
            <button
              onClick={() => handleScrollTo('sobre')}
              className="text-left py-2 hover:text-white transition-colors border-b border-slate-800/50"
            >
              Sobre Marcelo Farias
            </button>
            <button
              onClick={() => handleScrollTo('servicos')}
              className="text-left py-2 hover:text-white transition-colors border-b border-slate-800/50"
            >
              Serviços Especializados
            </button>
            <button
              onClick={() => handleScrollTo('diferenciais')}
              className="text-left py-2 hover:text-white transition-colors border-b border-slate-800/50"
            >
              Diferenciais Competitivos
            </button>
            <button
              onClick={() => handleScrollTo('portfolio')}
              className="text-left py-2 hover:text-white transition-colors border-b border-slate-800/50"
            >
              Projetos & Portfólio Pet Shop
            </button>
            <button
              onClick={() => handleScrollTo('depoimentos')}
              className="text-left py-2 hover:text-white transition-colors"
            >
              Depoimentos de Clientes
            </button>
          </nav>

          {onOpenDownloadModal && (
            <button
              onClick={() => {
                setIsMobileMenuOpen(false);
                onOpenDownloadModal();
              }}
              className="w-full mb-3 flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-emerald-300 bg-emerald-950/80 border border-emerald-600/50 rounded-lg"
            >
              <span>Baixar ZIP do Projeto (5.6 MB)</span>
            </button>
          )}

          <button
            onClick={handleCtaClick}
            className="w-full flex items-center justify-center gap-2 px-4 py-3 text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-md transition-colors"
          >
            <span>{BRAND_INFO.primaryCtaText}</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="mt-4 pt-3 flex items-center justify-between text-xs text-slate-400">
            <span>Brasil · Atendimento Nacional</span>
            <span className="flex items-center gap-1 text-blue-400">
              <ShieldCheck className="w-3.5 h-3.5" /> Entrega no mesmo dia
            </span>
          </div>
        </div>
      )}
    </header>
  );
}
