import { Instagram, MessageCircle, ArrowUp, ArrowRight, ShieldCheck, Zap } from 'lucide-react';
import { BRAND_INFO } from '../data/portfolioData';

interface FooterProps {
  onOpenProposal: () => void;
  onOpenDownloadModal?: () => void;
}

export default function Footer({ onOpenProposal, onOpenDownloadModal }: FooterProps) {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050914] text-slate-400 border-t border-slate-800/80 pt-16 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top zone: Brand & Quick Action */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 pb-12 border-b border-slate-800/80">
          
          <div className="md:col-span-5">
            <div className="flex items-center gap-2 mb-3">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
              <span className="text-xl font-bold text-white tracking-tight">Marcelo Farias</span>
              <span className="text-slate-400 text-sm">· Webnex Studio</span>
            </div>
            
            <p className="text-sm text-slate-300 italic mb-4">
              "{BRAND_INFO.tagline}"
            </p>
            
            <p className="text-xs text-slate-400 leading-relaxed max-w-sm mb-6">
              Criamos sites profissionais e landing pages com foco total em faturamento para Pet Shops, clínicas e negócios em expansão no Brasil.
            </p>

            <div className="flex items-center gap-4 text-xs">
              <a
                href={BRAND_INFO.instagramUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-slate-300 hover:text-white transition-colors"
              >
                <Instagram className="w-4 h-4 text-pink-400" />
                <span>@{BRAND_INFO.instagramHandle}</span>
              </a>
              <a
                href={BRAND_INFO.whatsappLink}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 text-slate-300 hover:text-emerald-400 transition-colors"
              >
                <MessageCircle className="w-4 h-4 text-emerald-400" />
                <span>{BRAND_INFO.whatsappFormatted}</span>
              </a>
            </div>
          </div>

          <div className="md:col-span-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
              Navegação
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#inicio" className="hover:text-white transition-colors">Início</a>
              </li>
              <li>
                <a href="#sobre" className="hover:text-white transition-colors">Sobre Marcelo Farias</a>
              </li>
              <li>
                <a href="#servicos" className="hover:text-white transition-colors">Serviços Especializados</a>
              </li>
              <li>
                <a href="#diferenciais" className="hover:text-white transition-colors">Diferenciais Competitivos</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-white transition-colors">Projetos & Portfólio</a>
              </li>
              <li>
                <a href="#depoimentos" className="hover:text-white transition-colors">Depoimentos</a>
              </li>
            </ul>
          </div>

          <div className="md:col-span-4 flex flex-col justify-between">
            <div>
              <h4 className="text-xs font-semibold text-white uppercase tracking-wider mb-4">
                Pronto para crescer?
              </h4>
              <p className="text-xs text-slate-400 mb-4">
                Solicite uma proposta sem compromisso e veja como colocar seu site no ar com rapidez e transparência.
              </p>
              <button
                onClick={onOpenProposal}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-all cursor-pointer shadow-md"
              >
                <span>{BRAND_INFO.primaryCtaText}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="mt-4 pt-3 flex items-center gap-3 text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Zap className="w-3 h-3 text-amber-400" /> Entrega no mesmo dia
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3 h-3 text-emerald-400" /> Atendimento direto
              </span>
            </div>
          </div>

        </div>

        {/* Bottom copyright line & Project Download */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>© {new Date().getFullYear()} Webnex Studio · Marcelo Farias. Todos os direitos reservados. Brasil.</p>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenDownloadModal}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium shadow-md transition-all cursor-pointer"
              title="Central de Download com garantia de arquivo completo (5.6 MB)"
            >
              <Zap className="w-4 h-4 text-white" />
              <span>Baixar ZIP do Projeto (5.6 MB)</span>
            </button>

            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-colors cursor-pointer py-1"
            >
              <span>Voltar ao topo</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}
