import { Star, Quote, ArrowRight } from 'lucide-react';
import { TESTIMONIALS_LIST, BRAND_INFO } from '../data/portfolioData';

interface TestimonialsProps {
  onOpenProposal: () => void;
}

export default function Testimonials({ onOpenProposal }: TestimonialsProps) {
  return (
    <section id="depoimentos" className="py-20 md:py-28 relative bg-[#070d1e] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="max-w-3xl mb-16">
          <p className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-3">
            Depoimentos & Casos Reais
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-4 text-balance">
            O que dizem os empresários que confiam na Webnex Studio
          </h2>
          <p className="text-base text-slate-300">
            Mais do que um site bonito: resultados expressivos em agendamentos, clientes novos e faturamento real.
          </p>
        </div>

        {/* Testimonials 3-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS_LIST.map((item) => (
            <div
              key={item.id}
              className="p-6 sm:p-7 rounded-2xl bg-slate-900/60 border border-slate-800 flex flex-col justify-between hover:border-slate-700 transition-all duration-300 group"
            >
              <div>
                {/* Rating & Quote mark */}
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-1">
                    {[...Array(item.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <Quote className="w-5 h-5 text-slate-600 group-hover:text-blue-400 transition-colors" />
                </div>

                {/* Body Quote */}
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed italic mb-6">
                  "{item.quote}"
                </p>
              </div>

              {/* Outcome Badge & Author Lockup */}
              <div className="pt-4 border-t border-slate-800">
                <div className="mb-3 px-3 py-1.5 rounded-md bg-emerald-950/60 border border-emerald-800/50 text-emerald-300 text-xs font-semibold flex items-center justify-between">
                  <span>Resultado:</span>
                  <span className="font-mono">{item.result}</span>
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">
                    {item.name}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {item.role} · <span className="text-slate-300">{item.business}</span>
                  </p>
                  <p className="text-[11px] text-blue-400 font-medium mt-0.5">
                    {item.segment}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Social Proof Strip & Call to Action */}
        <div className="mt-14 p-6 sm:p-8 rounded-2xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left">
          <div>
            <h3 className="text-lg font-bold text-white mb-1">
              Pronto para ser a próxima história de sucesso na sua cidade?
            </h3>
            <p className="text-xs sm:text-sm text-slate-300">
              Gere propostas personalizadas em poucos cliques e converse diretamente com Marcelo Farias.
            </p>
          </div>
          <button
            onClick={onOpenProposal}
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-md transition-all whitespace-nowrap shrink-0 cursor-pointer"
          >
            <span>{BRAND_INFO.primaryCtaText}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
}
