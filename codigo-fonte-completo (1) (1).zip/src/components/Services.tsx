import { ArrowRight, Check, Zap, Bot, Globe, Smartphone, Compass, RefreshCw } from 'lucide-react';
import { SERVICES_LIST, BRAND_INFO } from '../data/portfolioData';

interface ServicesProps {
  onSelectService: (serviceId: string) => void;
}

export default function Services({ onSelectService }: ServicesProps) {
  const getServiceIcon = (id: string) => {
    switch (id) {
      case 'sites-profissionais':
        return <Globe className="w-5 h-5 text-blue-400" />;
      case 'landing-pages':
        return <Zap className="w-5 h-5 text-amber-400" />;
      case 'sites-petshop-empresas':
        return <Smartphone className="w-5 h-5 text-emerald-400" />;
      case 'otimizacao-presenca':
        return <Compass className="w-5 h-5 text-sky-400" />;
      case 'atualizacao-suporte':
        return <RefreshCw className="w-5 h-5 text-indigo-400" />;
      case 'agentes-ia':
        return <Bot className="w-5 h-5 text-purple-400" />;
      default:
        return <Globe className="w-5 h-5 text-blue-400" />;
    }
  };

  return (
    <section id="servicos" className="py-20 md:py-28 relative bg-[#0b1329] border-t border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header section with clean hierarchy */}
        <div className="max-w-3xl mb-16">
          <p className="text-xs font-semibold text-blue-400 tracking-wider uppercase mb-3">
            Soluções & Serviços
          </p>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold tracking-tight text-white mb-4 text-balance">
            Soluções completas para atrair clientes e impulsionar suas vendas
          </h2>
          <p className="text-base text-slate-300">
            Cada serviço foi formatado para resolver um gargalo real de crescimento. Do nicho especializado de Pet Shops até integrações avançadas de inteligência artificial.
          </p>
        </div>

        {/* 6 Services Grid (Asymmetric Bento styling) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES_LIST.map((service, index) => {
            const isFeatured = service.badge !== undefined;
            return (
              <div
                key={service.id}
                className={`flex flex-col justify-between p-6 sm:p-7 rounded-2xl transition-all duration-300 group ${
                  isFeatured
                    ? 'bg-slate-900/90 border border-blue-500/40 shadow-xl shadow-blue-950/20 hover:border-blue-400'
                    : 'bg-slate-900/60 border border-slate-800 hover:border-slate-700 hover:bg-slate-900/90'
                }`}
              >
                <div>
                  {/* Top line: index and icon */}
                  <div className="flex items-center justify-between mb-5">
                    <span className="font-mono text-xs text-slate-400 font-semibold tracking-wider">
                      0{index + 1}. SERVIÇO
                    </span>
                    <div className="flex items-center gap-2">
                      {service.badge && (
                        <span className="text-[11px] font-semibold text-blue-300 bg-blue-950/80 border border-blue-800/60 px-2.5 py-0.5 rounded">
                          {service.badge}
                        </span>
                      )}
                      <div className="p-2 rounded-lg bg-slate-800/80 border border-slate-700/60">
                        {getServiceIcon(service.id)}
                      </div>
                    </div>
                  </div>

                  {/* Title & Short description */}
                  <h3 className="text-lg sm:text-xl font-bold text-white mb-2.5 group-hover:text-blue-300 transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
                    {service.shortDesc}
                  </p>

                  {/* Ideal for box */}
                  <div className="mb-5 p-3 rounded-lg bg-[#060a17]/60 border border-slate-800/70 text-xs text-slate-300">
                    <span className="text-slate-400 font-medium block mb-1">Para quem é ideal:</span>
                    {service.idealFor}
                  </div>

                  {/* Deliverables checklist */}
                  <div className="space-y-2 mb-6">
                    <p className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                      O que está incluso:
                    </p>
                    {service.deliverables.map((item, dIdx) => (
                      <div key={dIdx} className="flex items-start gap-2 text-xs text-slate-300">
                        <Check className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Footer of card: turnaround and action */}
                <div className="pt-4 border-t border-slate-800/80 flex flex-col gap-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Prazo estimado:</span>
                    <span className="font-medium text-blue-300">{service.turnaroundTime}</span>
                  </div>

                  <button
                    onClick={() => onSelectService(service.id)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 text-xs sm:text-sm font-semibold rounded-lg bg-slate-800 hover:bg-blue-600 text-slate-200 hover:text-white transition-all cursor-pointer group/btn"
                  >
                    <span>Solicitar proposta deste serviço</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Global CTA Banner inside Services */}
        <div className="mt-16 p-8 rounded-2xl bg-gradient-to-r from-blue-950/70 via-slate-900 to-slate-900 border border-blue-900/40 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h4 className="text-lg sm:text-xl font-bold text-white mb-1">
              Dúvida sobre qual formato é o melhor para seu negócio?
            </h4>
            <p className="text-xs sm:text-sm text-slate-300">
              Conversamos direto pelo WhatsApp e indicamos exatamente a estrutura com maior retorno sobre investimento.
            </p>
          </div>
          <a
            href={BRAND_INFO.whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl transition-all whitespace-nowrap shrink-0 shadow-lg"
          >
            <span>Falar com Marcelo no WhatsApp</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

      </div>
    </section>
  );
}
