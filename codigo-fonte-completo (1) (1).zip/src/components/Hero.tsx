import { ArrowRight, CheckCircle2, Zap, Clock, ShieldCheck, Sparkles } from 'lucide-react';
import { BRAND_INFO, METRICS_DATA } from '../data/portfolioData';

interface HeroProps {
  onOpenProposal: () => void;
  onExplorePortfolio: () => void;
}

export default function Hero({ onOpenProposal, onExplorePortfolio }: HeroProps) {
  return (
    <section id="inicio" className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden">
      {/* Background radial gradient accents */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[650px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none -z-10" />
      <div className="absolute top-20 right-10 w-[300px] h-[300px] bg-indigo-500/5 rounded-full blur-[90px] pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Proposition & CTA */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            
            {/* Tagline kicker: clean unboxed metadata with subtle dot */}
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-md bg-blue-950/60 border border-blue-800/40 text-blue-300 text-xs sm:text-sm font-medium mb-6">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>{BRAND_INFO.tagline}</span>
              <span className="text-slate-500">·</span>
              <span className="text-slate-300">Webnex Studio</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.12] mb-6 max-w-2xl text-balance">
              Transforme sua empresa em uma <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-blue-200 to-white">referência de mercado</span> que vende todos os dias.
            </h1>

            {/* Subheadline focused on target audience and value proposition */}
            <p className="text-base sm:text-lg text-slate-300 leading-relaxed mb-8 max-w-2xl">
              Criamos sites profissionais e landing pages sob medida focadas em aumentar o faturamento e escalar a lucratividade do seu negócio. Especialidade no <strong className="text-white font-semibold">nicho Pet Shop</strong>, clínicas e empresas locais, com a agilidade exclusiva de <span className="text-blue-300 font-medium">entrega no mesmo dia</span>.
            </p>

            {/* Primary Action Button (The single main action) */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto mb-8">
              <button
                onClick={onOpenProposal}
                className="inline-flex items-center justify-center gap-3 px-7 py-4 text-sm sm:text-base font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-xl shadow-lg shadow-blue-600/25 active:scale-[0.98] transition-all cursor-pointer group text-center"
              >
                <span>{BRAND_INFO.primaryCtaText}</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <button
                onClick={onExplorePortfolio}
                className="inline-flex items-center justify-center gap-2 px-6 py-4 text-sm sm:text-base font-medium text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800/80 border border-slate-800 rounded-xl transition-all cursor-pointer text-center"
              >
                <span>Ver Projetos & Casos Reais</span>
              </button>
            </div>

            {/* Trust bullet highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 w-full pt-4 border-t border-slate-800/80 text-xs sm:text-sm text-slate-300">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0" />
                <span>Atendimento direto com Marcelo</span>
              </div>
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Opção de entrega no mesmo dia</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Preço transparente e sem surpresas</span>
              </div>
            </div>

          </div>

          {/* Right Column: Visual Hero Workspace Mockup */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto rounded-2xl p-2 bg-gradient-to-b from-slate-700/40 via-slate-800/20 to-slate-900/60 border border-slate-700/50 shadow-2xl shadow-black/60 group">
              
              {/* Image Frame with fallback */}
              <div className="relative rounded-xl overflow-hidden aspect-[16/10] bg-[#0c142b]">
                <img
                  src="./images/hero_webnex_workspace_1794252804684.jpg"
                  alt="Estúdio criativo Webnex Studio e estação de design de Marcelo Farias"
                  className="w-full h-full object-cover object-center group-hover:scale-[1.02] transition-transform duration-500"
                  loading="eager"
                  referrerPolicy="no-referrer"
                />
                
                {/* Visual overlay gradient for crisp typography */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#060a17]/90 via-transparent to-black/20 pointer-events-none" />

                {/* Micro floating live result card */}
                <div className="absolute bottom-4 left-4 right-4 p-3.5 rounded-lg bg-[#0b1329]/95 backdrop-blur-md border border-slate-700/80 flex items-center justify-between gap-3 shadow-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-md bg-blue-600/20 border border-blue-500/40 flex items-center justify-center text-blue-400 font-bold text-sm">
                      WF
                    </div>
                    <div>
                      <p className="text-xs font-semibold text-white">Nicho Pet Shop & Empresas</p>
                      <p className="text-[11px] text-slate-400">Sites com agendamento via WhatsApp</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-bold text-emerald-400 font-mono">+185%</span>
                    <p className="text-[10px] text-slate-400">Conversão</p>
                  </div>
                </div>
              </div>

              {/* Status footer strip */}
              <div className="flex items-center justify-between px-3 py-2 text-[11px] text-slate-400">
                <span className="flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
                  Agenda aberta para novos projetos
                </span>
                <span className="font-mono text-slate-400">Webnex Studio · Brasil</span>
              </div>
            </div>
          </div>

        </div>

        {/* Quantified Metrics Proof Strip below Hero */}
        <div className="mt-16 sm:mt-20 grid grid-cols-2 lg:grid-cols-4 gap-4 p-5 sm:p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 backdrop-blur-sm">
          {METRICS_DATA.map((item, index) => (
            <div key={index} className="flex flex-col border-l first:border-l-0 border-slate-800 pl-4 sm:pl-6">
              <span className="text-2xl sm:text-3xl font-extrabold text-white font-mono tabular-nums tracking-tight">
                {item.value}
              </span>
              <span className="text-xs sm:text-sm font-medium text-slate-200 mt-0.5">
                {item.label}
              </span>
              <span className="text-[11px] text-slate-400 mt-0.5">
                {item.context}
              </span>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
