import { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Differentiators from './components/Differentiators';
import Portfolio from './components/Portfolio';
import Testimonials from './components/Testimonials';
import ProposalForm from './components/ProposalForm';
import FloatingWhatsApp from './components/FloatingWhatsApp';
import Footer from './components/Footer';
import DownloadModal from './components/DownloadModal';

export default function App() {
  const [selectedServiceId, setSelectedServiceId] = useState<string | undefined>(undefined);
  const [projectNote, setProjectNote] = useState<string | undefined>(undefined);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  const scrollToProposal = () => {
    const el = document.getElementById('proposta');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectService = (serviceId: string) => {
    setSelectedServiceId(serviceId);
    scrollToProposal();
  };

  const handleRequestSimilarProject = (projectTitle: string) => {
    setProjectNote(`Gostei do estilo do projeto "${projectTitle}"`);
    scrollToProposal();
  };

  const handleExplorePortfolio = () => {
    const el = document.getElementById('portfolio');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0b1329] text-slate-100 flex flex-col selection:bg-blue-600 selection:text-white">
      {/* Top Bar Navigation with Download Modal Trigger */}
      <Header
        onOpenProposalModal={scrollToProposal}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* 1. Hero Impact Section */}
        <Hero
          onOpenProposal={scrollToProposal}
          onExplorePortfolio={handleExplorePortfolio}
        />

        {/* 2. About Marcelo Farias & Webnex Studio */}
        <About onOpenProposal={scrollToProposal} />

        {/* 3. The 6 Specialized Services */}
        <Services onSelectService={handleSelectService} />

        {/* 4. The 6 Competitive Differentiators */}
        <Differentiators onOpenProposal={scrollToProposal} />

        {/* 5. Interactive Portfolio with Pet Shop Highlight */}
        <Portfolio onRequestSimilarProject={handleRequestSimilarProject} />

        {/* 6. Attributable Testimonials */}
        <Testimonials onOpenProposal={scrollToProposal} />

        {/* 7. Central Proposal Form (The Primary Visitor Action) */}
        <ProposalForm
          initialServiceId={selectedServiceId}
          initialProjectNote={projectNote}
        />
      </main>

      {/* 8. Quiet Footer */}
      <Footer
        onOpenProposal={scrollToProposal}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* 9. Floating WhatsApp for Direct Contact */}
      <FloatingWhatsApp />

      {/* 10. Official Project Download Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
      />
    </div>
  );
}
