import { ServiceItem, ProjectItem, TestimonialItem, DifferentiatorItem } from '../types';

export const BRAND_INFO = {
  name: "Marcelo Farias",
  agency: "Webnex Studio",
  tagline: "Mais que sites, criamos oportunidades.",
  whatsappNumber: "91982358580",
  whatsappFormatted: "(91) 98235-8580",
  whatsappLink: "https://wa.me/5591982358580?text=Ol%C3%A1%20Marcelo!%20Gostaria%20de%20solicitar%20uma%20proposta%20de%20site%20para%20minha%20empresa.",
  instagramHandle: "webnexx.studio",
  instagramUrl: "https://instagram.com/webnexx.studio",
  region: "Brasil (Atendimento Nacional)",
  primaryCtaText: "Solicitar uma proposta de site para minha empresa",
};

export const SERVICES_LIST: ServiceItem[] = [
  {
    id: "sites-profissionais",
    title: "Criação de Sites Profissionais",
    shortDesc: "Estruturas completas, ultra rápidas e responsivas para consolidar sua autoridade no mercado.",
    fullDesc: "Desenvolvimento do zero de sites institucionais modernos, leves e otimizados para qualquer tela. Arquitetura pensada para transmitir máxima credibilidade e converter visitantes casuais em clientes fiéis.",
    idealFor: "Empresas e clínicas que buscam presença sólida e autoridade incontestável no Google.",
    deliverables: [
      "Design 100% sob medida para sua identidade visual",
      "Otimização para celulares e tablets (Mobile-First)",
      "Botão de WhatsApp e agendamento direto integrado",
      "Estrutura otimizada para carregamento ultra rápido"
    ],
    turnaroundTime: "A partir de 24h a 3 dias úteis"
  },
  {
    id: "landing-pages",
    title: "Landing Pages de Alta Conversão",
    shortDesc: "Páginas focadas em um único objetivo: transformar cliques de anúncios em vendas imediatas.",
    fullDesc: "Copywriting persuasivo, carregamento instantâneo e layout sem distrações para potencializar campanhas de tráfego pago no Google Ads, Instagram e Facebook Ads.",
    idealFor: "Lançamento de ofertas, serviços específicos, promoções e captura de leads qualificados.",
    deliverables: [
      "Copywriting comercial direcionado para fechar negócios",
      "Design focado na jornada do usuário e gatilhos mentais",
      "Integração com pixel de rastreamento e analytics",
      "Opção de entrega prioritária rápida"
    ],
    turnaroundTime: "Disponível com entrega no mesmo dia",
    badge: "Alta Conversão"
  },
  {
    id: "sites-petshop-empresas",
    title: "Sites para Pet Shops e Profissionais",
    shortDesc: "Especialidade comprovada no nicho Pet Shop, clínicas veterinárias e prestadores autônomos.",
    fullDesc: "Soluções completas com apresentação de serviços de banho, tosa, hotelzinho, consultas veterinárias e agendamento rápido com cardápio de serviços direto no WhatsApp.",
    idealFor: "Pet shops, clínicas veterinárias, médicos, consultores e prestadores de serviços locais.",
    deliverables: [
      "Menu interativo de serviços (Banho, Tosa, Vacinas, Consultas)",
      "Sistema prático de solicitação de horário via WhatsApp",
      "Galeria de fotos do espaço físico e depoimentos de tutores",
      "Localização e rota no Google Maps integrados"
    ],
    turnaroundTime: "1 a 2 dias úteis",
    badge: "Nicho Especialista"
  },
  {
    id: "otimizacao-presenca",
    title: "Otimização da Presença Digital",
    shortDesc: "Posicionamento local estratégico para sua empresa ser a primeira escolha da sua cidade.",
    fullDesc: "Alinhamento completo entre seu site, Google Meu Negócio, palavras-chave locais e técnicas de SEO que colocam seu negócio na rota de quem procura o seu serviço agora.",
    idealFor: "Negócios que querem atrair clientes locais sem depender exclusivamente de anúncios pagos.",
    deliverables: [
      "Configuração e refinamento do perfil Google Meu Negócio",
      "SEO on-page para buscas locais da sua cidade e bairro",
      "Indexação acelerada nos mecanismos de busca do Google",
      "Métricas de cliques e chamadas de clientes"
    ],
    turnaroundTime: "Entrega em até 48 horas"
  },
  {
    id: "atualizacao-suporte",
    title: "Atualização de Conteúdo & Suporte",
    shortDesc: "Seu site sempre atual, seguro e funcionando sem que você precise se preocupar com técnica.",
    fullDesc: "Cuidamos de atualizações de preços, promoções sazonais, fotos de novos produtos e manutenção de segurança para seu site nunca ficar obsoleto ou fora do ar.",
    idealFor: "Empresários que não têm tempo a perder com código e querem agilidade total no suporte.",
    deliverables: [
      "Atendimento direto com Marcelo Farias sem burocracia",
      "Alterações rápidas de banners, textos e telefones",
      "Monitoramento de estabilidade e segurança contínua",
      "Backups periódicos e garantia de funcionamento"
    ],
    turnaroundTime: "Respostas em minutos"
  },
  {
    id: "agentes-ia",
    title: "Integração de Agentes de IA",
    shortDesc: "Atendimento inteligente que responde dúvidas e qualifica clientes 24 horas por dia.",
    fullDesc: "Implementação de assistentes virtuais de inteligência artificial conectados ao seu site e WhatsApp para tirar dúvidas frequentes, filtrar orçamentos e agendar clientes mesmo de madrugada.",
    idealFor: "Empresas que perdem vendas fora do horário comercial ou recebem alto volume de mensagens repetitivas.",
    deliverables: [
      "Agente treinado com os preços e serviços da sua empresa",
      "Encaminhamento inteligente para o atendimento humano",
      "Disponibilidade 24 horas por dia, 7 dias por semana",
      "Aumento imediato na retenção e velocidade de resposta"
    ],
    turnaroundTime: "2 a 4 dias úteis",
    badge: "Tecnologia de Ponta"
  }
];

export const DIFFERENTIATORS_LIST: DifferentiatorItem[] = [
  {
    id: "entrega-mesmo-dia",
    title: "Entrega no mesmo dia",
    description: "Para projetos essenciais e landing pages rápidas, temos um fluxo enxuto que permite colocar sua página no ar em poucas horas.",
    proof: "Metodologia ágil sem etapas desnecessárias que travam seu negócio.",
    iconName: "Zap"
  },
  {
    id: "atendimento-direto",
    title: "Atendimento direto e personalizado",
    description: "Você fala diretamente com Marcelo Farias, o criador da Webnex Studio. Sem intermediários, estagiários ou filas de chamados.",
    proof: "Linha direta para tirar dúvidas, aprovar etapas e alinhar cada detalhe.",
    iconName: "UserCheck"
  },
  {
    id: "sites-personalizados",
    title: "Sites sob medida para seu negócio",
    description: "Nada de templates copiados da internet. Cada projeto é construído respeitando as particularidades e metas de lucro do seu mercado.",
    proof: "Design exclusivo que valoriza a identidade visual da sua marca.",
    iconName: "Sparkles"
  },
  {
    id: "preco-transparente",
    title: "Preço acessível e transparente",
    description: "Investimento claro desde a proposta, sem taxas ocultas, surpresas no final do mês ou letras miúdas contratuais.",
    proof: "Condições justas para pequenas, médias empresas e profissionais autônomos.",
    iconName: "ShieldCheck"
  },
  {
    id: "comunicacao-humana",
    title: "Comunicação próxima e humanizada",
    description: "Falamos a língua do seu negócio, sem jargões técnicos difíceis. Entendemos suas dores para desenhar a melhor solução.",
    proof: "Parceria genuína focada no crescimento e na escalabilidade do seu negócio.",
    iconName: "MessageCircle"
  },
  {
    id: "agilidade-suporte",
    title: "Agilidade para atender e dar suporte",
    description: "Precisou de uma alteração urgente ou suporte técnico? Nossa prioridade é resolver no menor tempo possível.",
    proof: "Tempo de primeira resposta médio inferior a 15 minutos via WhatsApp.",
    iconName: "Clock"
  }
];

export const PROJECTS_LIST: ProjectItem[] = [
  {
    id: "aumigo-pet-care",
    title: "Paws & Whiskers · Pet Club & Vet Care",
    category: "petshop",
    categoryLabel: "Pet Shop & Clínica Veterinária",
    client: "Rede Paws & Whiskers",
    resultMetric: "+185%",
    metricLabel: "em agendamentos de banho, tosa e consultas veterinárias em 60 dias",
    description: "Plataforma digital completa para pet shop com catálogo de planos de assinatura de banho/tosa, cardápio de serviços médicos e botão de agendamento via WhatsApp integrado.",
    features: [
      "Cardápio visual de serviços com preços claros",
      "Agendamento direto para atendimento via WhatsApp",
      "Depoimentos de tutores com fotos e avaliações",
      "Velocidade de carregamento móvel em 0.8s"
    ],
    imageUrl: "./images/showcase_petshop_project_1794252805637.jpg",
    highlight: true
  },
  {
    id: "synapse-ai-growth",
    title: "Synapse Growth · Soluções Empresariais com IA",
    category: "ia",
    categoryLabel: "Landing Page Corporativa & IA",
    client: "Synapse B2B Hub",
    resultMetric: "+42%",
    metricLabel: "de conversão de visitantes frios em orçamentos qualificados",
    description: "Landing page corporativa de alta autoridade com agente de inteligência artificial integrado para triagem de leads corporativos e demonstração interativa de serviços.",
    features: [
      "Assistente virtual inteligente para qualificação de leads",
      "Dashboard demonstrativo com métricas de retorno",
      "Copywriting com proposta de valor cristalina",
      "Design escuro minimalista moderno de alto padrão"
    ],
    imageUrl: "./images/showcase_corporate_ai_project_1794252805842.jpg",
    highlight: true
  },
  {
    id: "estetica-canina-vip",
    title: "Centro de Estética Animal & Hotel Pet",
    category: "petshop",
    categoryLabel: "Landing Page de Alta Conversão",
    client: "Bella Groomer Pet House",
    resultMetric: "1º Lugar",
    metricLabel: "em buscas locais no Google Maps para banho & tosa na região",
    description: "Landing page de vendas rápidas estruturada para captar tutores em busca de tratamento premium para cães e gatos, integrando galeria de antes/depois e botão direto de rota.",
    features: [
      "Galeria de transformações e tosa na tesoura",
      "Tabela transparente de portes e pacotes mensais",
      "Integração com Google Meu Negócio e avaliações 5 estrelas",
      "Entrega realizada no mesmo dia para campanha urgente"
    ],
    imageUrl: "./images/showcase_petshop_project_1794252805637.jpg"
  },
  {
    id: "nexus-consultoria",
    title: "Webnex Studio Workspace & Design System",
    category: "institucional",
    categoryLabel: "Site Profissional Institucional",
    client: "Webnex Studio",
    resultMetric: "100/100",
    metricLabel: "pontuação de performance e SEO no Google Lighthouse",
    description: "A própria presença da Webnex Studio com arquitetura moderna, visual minimalista refinado e estrutura otimizada para captação de clientes em todo o território nacional.",
    features: [
      "Arquitetura moderna baseada em Tailwind e React",
      "Simulador interativo de propostas em tempo real",
      "Contraste WCAG AA para máxima legibilidade",
      "Integração nativa com WhatsApp comercial"
    ],
    imageUrl: "./images/hero_webnex_workspace_1794252804684.jpg"
  }
];

export const TESTIMONIALS_LIST: TestimonialItem[] = [
  {
    id: "1",
    name: "Dra. Camila Vasconcelos",
    role: "Médica Veterinária e Sócia",
    business: "Clínica & Pet Shop AuMigo",
    segment: "Pet Shop & Veterinária",
    quote: "O Marcelo entendeu exatamente a realidade do nosso pet shop. Antes as pessoas ficavam perdidas perguntando preço de banho no direct. Com o site novo, os clientes já chegam prontos para agendar pelo WhatsApp. Nossos agendamentos dobraram em menos de 2 meses!",
    result: "Faturamento mensal de serviços +82%",
    rating: 5
  },
  {
    id: "2",
    name: "Rodrigo Almeida",
    role: "Diretor Comercial",
    business: "Almeida & Associados Soluções",
    segment: "Serviços Empresariais",
    quote: "O grande diferencial do Marcelo foi a agilidade e o atendimento direto. Sem enrolação de agência tradicional. Ele fez ajustes no mesmo dia e nossa landing page começou a gerar reuniões comerciais na mesma semana em que subimos a campanha.",
    result: "Custo por lead qualificado reduzido em 47%",
    rating: 5
  },
  {
    id: "3",
    name: "Patrícia Moura",
    role: "Fundadora",
    business: "Patas & Pelos Boutique Pet",
    segment: "Banho, Tosa & Estética Animal",
    quote: "Eu precisava de uma página rápida para o lançamento da nossa nova unidade e ele entregou com uma velocidade impressionante! O visual ficou limpo, chique e moderno. Valeu cada centavo investido.",
    result: "Agenda lotada na semana de inauguração",
    rating: 5
  }
];

export const METRICS_DATA = [
  { value: "No mesmo dia", label: "Opção de entrega prioritária", context: "Agilidade recorde" },
  { value: "+180%", label: "Média de aumento em contatos", context: "Foco em faturamento" },
  { value: "100%", label: "Projetos sob medida", context: "Sem templates genéricos" },
  { value: "< 15 min", label: "Tempo de resposta no suporte", context: "Atendimento direto" }
];
