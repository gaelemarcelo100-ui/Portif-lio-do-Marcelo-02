export interface ServiceItem {
  id: string;
  title: string;
  shortDesc: string;
  fullDesc: string;
  idealFor: string;
  deliverables: string[];
  turnaroundTime: string;
  badge?: string;
}

export interface ProjectItem {
  id: string;
  title: string;
  category: 'petshop' | 'landing' | 'institucional' | 'ia';
  categoryLabel: string;
  client: string;
  resultMetric: string;
  metricLabel: string;
  description: string;
  features: string[];
  imageUrl: string;
  liveUrl?: string;
  highlight?: boolean;
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  business: string;
  segment: string;
  quote: string;
  result: string;
  rating: number;
}

export interface DifferentiatorItem {
  id: string;
  title: string;
  description: string;
  proof: string;
  iconName: string;
}

export interface ProposalFormData {
  fullName: string;
  whatsapp: string;
  companyName: string;
  segment: string;
  serviceId: string;
  urgency: 'same-day' | 'standard' | 'planning';
  budgetGoal: string;
  notes: string;
}
