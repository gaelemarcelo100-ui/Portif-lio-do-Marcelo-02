# Marcelo Farias | Webnex Studio — Portfólio Profissional

Portfólio de alta conversão para Marcelo Farias e Webnex Studio.
Especialidade em criação de sites e landing pages para o nicho Pet Shop e empresas que buscam escalar seu faturamento.

## 🚀 Tecnologias Utilizadas
- **React 19**
- **TypeScript**
- **Vite 8**
- **Tailwind CSS v4**
- **Lucide Icons**
- **Motion**

## 💻 Como Rodar o Projeto

1. Instale as dependências:
```bash
npm install
```

2. Inicie o servidor de desenvolvimento:
```bash
npm run dev
```

3. Para gerar a versão de produção:
```bash
npm run build
```

## 🌐 Deploy (Netlify / Vercel / Lovable)
- **Build Command:** `npm run build`
- **Publish Directory:** `dist`
- O arquivo `netlify.toml` e `public/_redirects` já estão inclusos para garantir o roteamento de SPA sem erros 404.
